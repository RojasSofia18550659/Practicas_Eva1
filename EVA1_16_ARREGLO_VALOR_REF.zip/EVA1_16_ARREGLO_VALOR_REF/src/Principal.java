/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int arreglo[] = new int[11];
        System.out.println(arreglo);
        llenarArreglo(arreglo);
        madrearArreglo(arreglo);
        System.out.println(arreglo);
        imprimirArreglo(arreglo);
    }
    public static void llenarArreglo(int[] fierro){
        for (int i = 0; i < fierro.length; i++) {
            fierro[i] = (int)(Math.random()* 100);
            
        }
        
        
    }
            public static void imprimirArreglo(int[] fierro){
              for (int i = 0; i < fierro.length; i++) {
                  System.out.println(" [" + fierro[i] + "]");
            
        }   
                System.out.println("");
            }
            public static void madrearArreglo(int[] fierro){
                fierro = new int [100];
                System.out.println(fierro);
            
            }

    
}
