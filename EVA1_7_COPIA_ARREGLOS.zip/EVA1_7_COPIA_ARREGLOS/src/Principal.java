/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hotel Don Ruben
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int aiDatos[];
        int aiCopia[];
        //INICIALIZACION DEL ARREGLO
        aiDatos = new int [10];
        aiCopia = new int [10];
        //Llenar con valores aleatorios 
        for (int i = 0; i < aiDatos.length; i++) {
            aiDatos[i] = (int)(Math.random()* 100)+1;   
            
        }
        System.out.println("ORIGINAL");
        
        for (int i = 0; i < aiDatos.length; i++) {
            aiDatos[i] = (int)(Math.random()* 100)+1;
            
        }
        System.out.println(aiDatos);
        System.out.println("COPIA"); 
        
        aiCopia=aiDatos;
        for (int i = 0; i < aiDatos.length; i++) {
            System.out.println("[" + aiCopia[i] + "]");
            
        }
    }
    
}
