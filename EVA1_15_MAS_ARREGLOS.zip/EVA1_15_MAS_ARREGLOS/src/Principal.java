/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int aNum=10;
        System.out.println("Valor = "+aNum);
        incrementa(aNum);
        System.out.println("Valor ="+aNum);
        //-------------------------------------
        System.out.println("");
        Prueba obj = new Prueba();
        obj.iVal = 10;
        System.out.println("Valor = "+obj.iVal);
        incrementaobj(obj);
        System.out.println("Valor = "+obj.iVal);
    }
    public static void incrementa (int iVal){
        iVal++;
    }
    public static void incrementaobj(Prueba obj){
        obj.iVal++;
    }
    
}
class Prueba{
    int iVal;
}
