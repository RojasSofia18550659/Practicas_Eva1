/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hotel Don Ruben
 */
import java.util.Scanner;
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Persona[] aiPersona = new Persona[5];
        Scanner sCaptu = new Scanner(System.in);
        for (int i = 0; i < aiPersona.length; i++) {
            aiPersona[i].nombre =sCaptu.nextLine();
        }
        imprimirArreglo(aiPersona);
        //COPIA ARREGLO
        Persona[] aCopia = new Persona[aiPersona.length];
        for (int i = 0; i < aiPersona.length; i++) {
            aCopia[i] = new Persona();
            aCopia[i].nombre = aiPersona[i].nombre;
             
        }
        imprimirArreglo(aCopia);
    }
    public static void imprimirArreglo(Persona[] args){
        for (int i = 0; i < args.length; i++) {
            System.out.println("nombre: "+ args[i].nombre);
            
        }
    }
    
}
class Persona{
    String nombre;
}