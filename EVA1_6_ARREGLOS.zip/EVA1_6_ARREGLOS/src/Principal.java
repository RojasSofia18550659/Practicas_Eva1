/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hotel Don Ruben
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int aiDatos[],a,b;
        int[] aiDatos2,x,y;
        //Iniciacion del arreglo
        aiDatos =new int [10];
        //Llenar valores aleatorios 
        for (int i = 0; i < aiDatos.length; i++) {
            aiDatos[i] = (int)(Math.random() * 100) +1;
            
        }
        aiDatos[4]=5000;
        aiDatos[69]=5000;
        System.out.println(aiDatos);
    }
    
}
